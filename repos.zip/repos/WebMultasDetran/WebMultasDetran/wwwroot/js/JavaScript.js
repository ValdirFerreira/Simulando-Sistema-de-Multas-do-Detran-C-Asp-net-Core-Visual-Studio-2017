﻿var ObjetoMulta = new Object();

ObjetoMulta.SalvarCarro = function () {

    var placa = $("#placa").val();

    $.ajax({
        type: "POST",
        url: "api/RegistrarCarro",
        data: { placa: placa },
        dataType: "JSON",
        success: function () {

        }

    });

    $("#placa").val("");
}


ObjetoMulta.ListarMultados = function () {
    var d = new Date();
    var hora = d.getHours();
    var minuto = d.getMinutes();
    var segundos = d.setSeconds();

    var dataAtualizacao = "Atualizado em : " + hora + ":" + minuto + ":" + segundos;

    $.ajax({
        type: "GET",
        url: "api/ListarMultados",
        dataType: "JSON",
        success: function (data) {

            $("#multados").html(dataAtualizacao);

            data.lista.forEach(function (item) {

                $("#multados").append("<br /> <label> " + item.placa + "-" + item.tipoInfracao + " </label> ");

            });


        }

    });

    setTimeout("ObjetoMulta.ListarMultados()", 10000);
}

$(function () {

    ObjetoMulta.ListarMultados();

    $("#salvar").click(function () {
        ObjetoMulta.SalvarCarro();
    });

});