﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Data.Config;
using Data.Entidades;
using Microsoft.AspNetCore.Mvc;
using WebMultasDetran.Models;

namespace WebMultasDetran.Controllers
{
    public class HomeController : Controller
    {


        private readonly Contexto _contexto;


        public HomeController()
        {
            _contexto = new Contexto();
        }


        [HttpPost("api/RegistrarCarro")]
        public void RegistrarCarro(Registro Registro)
        {
            Task Tarefa = CapturaPlaca(new PlacaCapturada
            {
                Placa = Registro.placa,
                DiaHora = DateTime.Now
            });
        }

        private async Task CapturaPlaca(PlacaCapturada PlacaCapturada)
        {
            try
            {
                _contexto.PlacaCapturada.Add(PlacaCapturada);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {

                throw;
            }
        }



        [HttpGet("api/ListarMultados")]
        public JsonResult ListarMultados()
        {
            try
            {
                var multados = _contexto.CarroMultado.ToList();
                return Json(new { lista = multados });
            }
            catch (Exception)
            {

                return Json(new { lista = new List<CarroMultado>() });
            }
        }



        #region OLD

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        #endregion
    }
}
