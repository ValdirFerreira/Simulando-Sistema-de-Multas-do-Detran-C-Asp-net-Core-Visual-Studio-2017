﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebMultasDetran.Controllers
{
    public class Registro
    {
        public string placa { get; set; }

    }
}
