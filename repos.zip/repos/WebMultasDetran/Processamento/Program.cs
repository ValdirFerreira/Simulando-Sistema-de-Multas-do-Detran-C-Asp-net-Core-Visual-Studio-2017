﻿using Data.Config;
using Data.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Processamento
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Processando!");

            while (true)
            {
                try
                {
                    Processar();
                }
                catch (Exception ex)
                {

                    Thread.Sleep(5000);
                }

                Thread.Sleep(10000);
            }

        }


        private static void Processar()
        {
            using (var contexto = new Contexto())
            {
                var placas = contexto.PlacaCapturada.Take(100).ToList();
                var removerSistema = new List<PlacaCapturada>();

                bool TemMulta = false;

                foreach (var item in placas)
                {
                    TemMulta = true;

                    var multado = VerificaCarro(item);
                    if (multado != null)
                    {
                        contexto.CarroMultado.Add(multado);
                    }
                    removerSistema.Add(item);

                }


                if (TemMulta)
                {
                    contexto.PlacaCapturada.RemoveRange(removerSistema);

                    contexto.SaveChanges();
                }


            }
        }

        private static CarroMultado VerificaCarro(PlacaCapturada PlacaCapturada)
        {

            string tipoMulta = string.Empty;

            bool aplicaMulta = false;

            int diaSemana = (int)DateTime.Now.DayOfWeek + 1;

            int numeroPlaca = Convert.ToInt32(PlacaCapturada.Placa.Substring(PlacaCapturada.Placa.Length - 1, 1));

            int final1 = 0;
            int final2 = 0;


            switch (diaSemana)
            {
                case 1:
                    final1 = 1;
                    final2 = 2;
                    break;

                case 2:
                    final1 = 3;
                    final2 = 4;
                    break;

                case 3:
                    final1 = 5;
                    final2 = 6;
                    break;

                case 4:
                    final1 = 7;
                    final2 = 8;
                    break;

                case 5:
                    final1 = 9;
                    final2 = 0;
                    break;
            }


            if (numeroPlaca == final1 || numeroPlaca == final2)
            {
                aplicaMulta = true;
            }


            if (aplicaMulta)
            {
                var retorno = new CarroMultado
                {
                    DataHora = PlacaCapturada.DiaHora,
                    Placa = PlacaCapturada.Placa,
                    TipoInfracao = "Multa Rodizio"
                };

                return retorno;

            }

            return null;

        }

    }
}
