﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Entidades
{
    public class PlacaCapturada
    {
        public int Id { get; set; }

        public string Placa { get; set; }

        public DateTime DiaHora { get; set; }
        
    }
}
