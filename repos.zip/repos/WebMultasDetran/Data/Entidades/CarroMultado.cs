﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Entidades
{
    public class CarroMultado
    {
        public int Id { get; set; }

        public string Placa { get; set; }

        public DateTime DataHora { get; set; }

        public string TipoInfracao { get; set; }
    }
}
