﻿using Data.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Data.Config
{
    public class Contexto : DbContext
    {

        public Contexto(DbContextOptions<Contexto> options) : base(options)
        {
            Database.EnsureCreated();
        }

        public Contexto()
        {
            Database.EnsureCreated();
        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionBuider)
        {
            if (!optionBuider.IsConfigured)
            {
                optionBuider.UseSqlServer("Data Source=DESKTOP-FLR1ARP;Initial Catalog=DetranMultado;Integrated Security=False;User ID=sa;Password=1234;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
            }
        }

        public DbSet<PlacaCapturada> PlacaCapturada { get; set; }

        public DbSet<CarroMultado> CarroMultado { get; set; }


    }
}
