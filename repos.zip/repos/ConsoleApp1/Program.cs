﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            double valor1 = -1.01;
            double valor2 = 0.00;
            double valor3 = -1.01;
            double valor4 = 1.01;
            double valor5 = -1.01;

            var lista = new List<Double>();
            lista.Add(valor1);
            lista.Add(valor2);
            lista.Add(valor3);
            lista.Add(valor4);
            lista.Add(valor5);


            var result = lista.Sum();

        }
    }
}
